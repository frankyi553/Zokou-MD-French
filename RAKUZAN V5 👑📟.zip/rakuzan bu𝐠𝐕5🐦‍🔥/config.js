const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["24106455798@s.whatsapp.net"]
global.nomerOwner = "24106455798"
global.nomorOwner = ['24106455798']
global.namaDeveloper = "rakuzan" //jangn diubh bng
global.namaOwner = "rakuzan"
global.namaBot = "🐉RAKUZAN |V5"
global.versionBot = "5.0"
global.packname = "🐉RAKUZAN |V5"
global.author = "🐉RAKUZAN |V5"
global.thumb = fs.readFileSync("./AndraZyy.png")
global.ThM = 'https://files.catbox.moe/5ph7bp.jpg'

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})